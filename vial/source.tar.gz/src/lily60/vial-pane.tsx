// SPDX-License-Identifier: GPL-2.0-or-later
import {useCallback, useEffect, useRef, useState} from 'react';
import {placeLayout} from '../components/keymap/layout/layoutGeometry';
import {UnlockDialog} from '../components/matrix/UnlockDialog';
import {useKeyboardRevision} from '../hooks/useKeyboardRevision';
import type {Keyboard} from '../protocol/keyboard';
import {Lily60Lighting} from './lighting';
import {Lily60RT} from './rt';
import type {Send} from './protocol';

function useLily60Send(keyboard: Keyboard) {
  return useCallback<Send>(packet => keyboard.sendLily60(Uint8Array.from(packet)), [keyboard]);
}

export function Lily60LightingPage({keyboard}: {keyboard: Keyboard}) {
  const send = useLily60Send(keyboard);
  return <Lily60Lighting send={send}/>;
}

export function Lily60RTPage({keyboard}: {keyboard: Keyboard}) {
  const [unlocking, setUnlocking] = useState(false);
  const unlockedForMonitor = useRef(false);
  useKeyboardRevision(keyboard);
  const send = useLily60Send(keyboard);
  const keys = placeLayout(keyboard.keys, keyboard.encoders, keyboard.layoutChoices).keys.map(({key, shiftX, shiftY}) => ({
    row: key.row, col: key.col, x: key.x + shiftX, y: key.y + shiftY, w: key.width, h: key.height,
    x2: key.x2, y2: key.y2, w2: key.width2, h2: key.height2,
  }));

  useEffect(() => () => {
    if (unlockedForMonitor.current) {
      unlockedForMonitor.current = false;
      void keyboard.lock().catch(() => {});
    }
  }, [keyboard]);

  return <div className="lily-rt-page">
    <Lily60RT send={send} keys={keys} paused={unlocking}
      unlock={<button type="button" onClick={() => setUnlocking(true)}>解锁实时监看（Esc + Tab）</button>}/>
    {unlocking && <UnlockDialog keyboard={keyboard} onCancel={() => setUnlocking(false)}
      onUnlocked={() => {unlockedForMonitor.current = true; setUnlocking(false);}}/>}
  </div>;
}
