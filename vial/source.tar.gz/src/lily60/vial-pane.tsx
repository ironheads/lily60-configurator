// SPDX-License-Identifier: GPL-2.0-or-later
import {useCallback, useEffect, useRef, useState} from 'react';
import {placeLayout} from '../components/keymap/layout/layoutGeometry';
import {UnlockDialog} from '../components/matrix/UnlockDialog';
import {useKeyboardRevision} from '../hooks/useKeyboardRevision';
import type {Keyboard} from '../protocol/keyboard';
import {Lily60Lighting} from './lighting';
import {Lily60RT} from './rt';
import type {Send} from './protocol';

export function Lily60Pane({keyboard}: {keyboard: Keyboard}) {
  const [page, setPage] = useState<'lighting' | 'rt'>('lighting');
  const [unlocking, setUnlocking] = useState(false);
  const unlockedForMonitor = useRef(false);
  useKeyboardRevision(keyboard);
  const send = useCallback<Send>(packet => keyboard.sendLily60(Uint8Array.from(packet)), [keyboard]);
  const keys = placeLayout(keyboard.keys, keyboard.encoders, keyboard.layoutChoices).keys.map(({key, shiftX, shiftY}) => ({
    row: key.row, col: key.col, x: key.x + shiftX, y: key.y + shiftY, w: key.width, h: key.height,
    x2: key.x2, y2: key.y2, w2: key.width2, h2: key.height2,
  }));

  useEffect(() => () => {
    if (unlockedForMonitor.current) {
      unlockedForMonitor.current = false;
      void keyboard.lock().catch(() => {});
    }
  }, [keyboard, page]);

  if (!keyboard.lily60Rt) return <Lily60Lighting send={send}/>;

  return <>
    <div className="lily-panel lily-tabs" aria-label="Lily60 设置">
      <button type="button" aria-pressed={page === 'lighting'} onClick={() => setPage('lighting')}>灯光</button>
      <button type="button" aria-pressed={page === 'rt'} onClick={() => setPage('rt')}>逐键 RT 与传感器</button>
    </div>
    {page === 'lighting' ? <Lily60Lighting send={send}/> : <Lily60RT send={send} keys={keys} paused={unlocking}
      unlock={<button type="button" onClick={() => setUnlocking(true)}>解锁实时监看（Esc + Tab）</button>}/>}
    {unlocking && <UnlockDialog keyboard={keyboard} onCancel={() => setUnlocking(false)}
      onUnlocked={() => {unlockedForMonitor.current = true; setUnlocking(false);}}/>}
  </>;
}
