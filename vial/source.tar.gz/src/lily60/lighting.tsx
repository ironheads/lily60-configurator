// SPDX-License-Identifier: GPL-2.0-or-later
import {useEffect, useState, type PointerEvent} from 'react';
import {lightingCommand, type Send} from './protocol';
import './panel.css';

type Color = [number, number];
type Setting = {effect: number; enabled: boolean; brightness: number; speed: number; color: Color};
const masterEffects = [[0,'关闭'],[2,'常亮'],[6,'呼吸'],[13,'彩虹'],[8,'波浪'],[14,'跑马'],[26,'心跳'],[19,'颜色轮换']] as const;
const capsEffects = [[0,'常亮'],[1,'呼吸'],[2,'彩虹'],[3,'波浪']] as const;
const panels = ['RGB', 'LED 1', 'LED 2', 'LED 3', '统一颜色', '大写锁定'];
const clamp = (number: number) => Math.min(255, Math.max(0, Math.round(number)));
const colorStyle = ([h, s]: Color) => `hsl(${h * 360 / 255} ${s * 100 / 255}% ${100 - s * 50 / 255}%)`;

function Palette({value, save, disabled}: {value: Color; save: (color: Color) => void; disabled: boolean}) {
  const [draft, setDraft] = useState<Color>();
  const point = (e: PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setDraft([clamp(255 * (e.clientX - rect.left) / rect.width), clamp(255 * (rect.bottom - e.clientY) / rect.height)]);
  };
  return <div>
    <button type="button" disabled={disabled} onClick={() => setDraft(draft ? undefined : value)}>
      <span className="lily-swatch" style={{background: colorStyle(value)}}/>选择颜色…
    </button>
    {draft && <div className="lily-color-picker">
      <div className="lily-palette" tabIndex={0} aria-label="调色盘。左右键调色相，上下键调饱和度。"
        onPointerDown={e => {e.currentTarget.setPointerCapture(e.pointerId); point(e);}}
        onPointerMove={e => {if (e.currentTarget.hasPointerCapture(e.pointerId)) point(e);}}
        onKeyDown={e => {
          const steps: Record<string, Color> = {ArrowLeft: [-4,0], ArrowRight: [4,0], ArrowUp: [0,4], ArrowDown: [0,-4]};
          const step = steps[e.key];
          if (step) {e.preventDefault(); setDraft([(draft[0] + step[0] + 256) % 256, clamp(draft[1] + step[1])]);}
        }}>
        <i style={{left: `${draft[0] * 100 / 255}%`, top: `${100 - draft[1] * 100 / 255}%`, background: colorStyle(draft)}}/>
      </div>
      <button type="button" disabled={disabled} onClick={() => {save(draft); setDraft(undefined);}}>确定</button>
      <button type="button" onClick={() => setDraft(undefined)}>取消</button>
    </div>}
  </div>;
}

function Range({title, value, commit, disabled}: {title: string; value: number; commit: (v: number) => void; disabled: boolean}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  const save = () => {if (draft !== value) commit(draft);};
  return <label className="lily-row"><span>{title} · {draft}</span>
    <input type="range" min="0" max="255" value={draft} disabled={disabled} onChange={e => setDraft(Number(e.target.value))}
      onPointerUp={save} onKeyUp={save} onBlur={save}/>
  </label>;
}

async function readMaster(send: Send) {
  const data = await send([8, 0x41]);
  if (data.length !== 32 || data[0] !== 8 || data[1] !== 0x41) throw new Error('无法读取主灯效');
  return {effect: data[2] | (data[3] << 8), brightness: data[7], speed: data[4], color: [data[5], data[6]] as Color};
}

export function Lily60Lighting({send}: {send: Send}) {
  const [panel, setPanel] = useState(0);
  const [setting, setSetting] = useState<Setting>();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const master = panel === 0;
  const shared = panel === 4;
  const caps = panel === 5;
  const channel = caps ? 11 : shared ? 12 : 10;
  const colorField = caps || shared ? 2 : panel + 15;
  const brightnessField = shared ? 3 : (panel - 1) * 5 + 4;
  const enabledField = shared ? 1 : panel * 5;

  useEffect(() => {
    let live = true;
    setSetting(undefined);
    setError('');
    void (async () => {
      try {
        const state: Setting = {effect: 0, enabled: false, brightness: 0, speed: 0, color: [0,0]};
        if (master) Object.assign(state, await readMaster(send));
        else {
          state.color = await lightingCommand(send, channel, colorField) as Color;
          if (caps) {
            state.effect = (await lightingCommand(send, channel, 1))[0];
            state.speed = (await lightingCommand(send, channel, 3))[0];
          } else {
            state.enabled = Boolean((await lightingCommand(send, channel, enabledField))[0]);
            state.brightness = (await lightingCommand(send, channel, brightnessField))[0];
          }
        }
        if (live) setSetting(state);
      } catch {if (live) setError('无法读取灯光，请重新连接键盘。');}
    })();
    return () => {live = false;};
  }, [send, panel, master, caps, channel, colorField, brightnessField, enabledField]);

  const update = async (changes: Partial<Setting>, field: number, bytes: number[]) => {
    if (!setting || busy) return;
    setBusy(true);
    try {
      if (master) {
        const next = {...await readMaster(send), ...changes};
        await send([7, 0x41, next.effect & 255, next.effect >> 8, next.speed, ...next.color, next.brightness]);
        await send([9]);
      } else await lightingCommand(send, channel, field, bytes);
      setSetting({...setting, ...changes});
      setError('');
    } catch {setError('键盘没有确认保存，请重试。');}
    finally {setBusy(false);}
  };

  return <div className="lily-panel"><h2>灯光</h2>
    <div className="lily-lighting">
      <nav aria-label="灯光页签">{panels.map((title, index) => <button key={title} type="button" aria-pressed={panel === index}
        disabled={busy} onClick={() => setPanel(index)}>{title}</button>)}</nav>
      <section className="lily-card" aria-label={panels[panel]}>
        <h3>{panels[panel]}</h3>
        {error && <p role="status">{error}</p>}
        {!setting && !error && <p>正在读取键盘…</p>}
        {setting && <>
          {(master || caps) && <label className="lily-row"><span>灯效</span>
            <select value={setting.effect} disabled={busy} onChange={e => {const effect = Number(e.target.value); void update({effect}, 1, [effect]);}}>
              {(master ? masterEffects : capsEffects).map(([id, name]) => <option key={id} value={id}>{name}</option>)}
            </select>
          </label>}
          {!master && !caps && <label className="lily-row"><span>{shared ? '统一颜色和亮度' : '灯光开关'}</span>
            <input type="checkbox" checked={setting.enabled} disabled={busy}
              onChange={e => void update({enabled: e.target.checked}, enabledField, [Number(e.target.checked)])}/>
          </label>}
          {!master && !(caps && setting.effect === 2) && <div className="lily-row"><span>颜色</span>
            <Palette key={panel} value={setting.color} disabled={busy} save={color => void update({color}, colorField, color)}/>
          </div>}
          {!caps && <Range title={master ? '总亮度' : '亮度'} value={setting.brightness} disabled={busy}
            commit={brightness => void update({brightness}, brightnessField, [brightness])}/>}
          {(master ? setting.effect !== 0 && setting.effect !== 2 : caps && setting.effect !== 0) &&
            <Range title="灯效速度" value={setting.speed} disabled={busy} commit={speed => void update({speed}, 3, [speed])}/>}
          {caps && <p>大写锁定时三颗灯共用同一个颜色，跟随总亮度。普通灯光关闭时也会显示。</p>}
          {shared && <p>启用时覆盖三颗灯的独立颜色和亮度。每颗灯的开关仍独立。</p>}
        </>}
      </section>
    </div>
  </div>;
}
