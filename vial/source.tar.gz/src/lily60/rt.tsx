// SPDX-License-Identifier: GPL-2.0-or-later
import {useEffect, useRef, useState, type FormEvent, type ReactNode} from 'react';
import {encode, GET_GLOBAL, GET_KEY, INFO, rtCommand, SET_GLOBAL, SET_KEY, thresholds, uint16, type Send, type Settings, type Thresholds} from './protocol';
import labels from './physical-labels';
import './panel.css';

export type PhysicalKey = {
  row: number; col: number; x: number; y: number; w: number; h: number;
  x2?: number; y2?: number; w2?: number; h2?: number;
};

const coordinates = (key: PhysicalKey) => `${key.row},${key.col}`;
const labelsByPosition = labels as Record<string, string>;
const keyLabel = (key: PhysicalKey) => key.row === 0 && key.col === 13 && key.w > 1
  ? '⌫' : (labelsByPosition[coordinates(key)] ?? coordinates(key));
const names = {deadzone: '初始死区', press: '再次触发偏移', release: '释放偏移'};
const fieldNames = Object.keys(names) as Array<keyof Thresholds>;

type Reading = {
  settings: Settings; effective: Thresholds; enabled: boolean;
  raw: number; baseline: number; bottom: number; unlocked: boolean;
};

function SettingsForm({value, onChange, onSave, disabled, modeOptions, title}: {
  value: Settings; onChange: (value: Settings) => void; onSave: (event: FormEvent) => void;
  disabled: boolean; modeOptions: string[]; title: string;
}) {
  return <form onSubmit={onSave} className="lily-form">
    <label className="lily-row"><span>{title}</span>
      <select value={value.mode} onChange={e => onChange({...value, mode: Number(e.target.value)})} disabled={disabled}>
        {modeOptions.map((option, id) => <option key={option} value={id}>{option}</option>)}
      </select>
    </label>
    {fieldNames.map(field => <label key={field} className="lily-row"><span>{names[field]}</span>
      <input required type="number" min={1} max={field === 'deadzone' ? 1023 : 255} step={1}
        value={value[field] || ''} disabled={disabled}
        onChange={e => onChange({...value, [field]: Number(e.target.value)})}/>
    </label>)}
    <button type="submit" disabled={disabled}>保存到键盘</button>
  </form>;
}

function KeyboardMap({keys, selected, select, disabled}: {
  keys: PhysicalKey[]; selected: string; select: (key: PhysicalKey) => void; disabled: boolean;
}) {
  const left = Math.min(0, ...keys.map(k => k.x + Math.min(0, k.x2 ?? 0)));
  const right = Math.max(15, ...keys.map(k => k.x + Math.max(k.w, (k.x2 ?? 0) + (k.w2 ?? k.w))));
  const top = Math.min(0, ...keys.map(k => k.y + Math.min(0, k.y2 ?? 0)));
  const bottom = Math.max(5, ...keys.map(k => k.y + Math.max(k.h, (k.y2 ?? 0) + (k.h2 ?? k.h))));
  return <svg className="lily-keyboard" viewBox={`${left} ${top} ${right - left} ${bottom - top}`} aria-label="当前键盘配列">
    {keys.map(key => {
      const id = coordinates(key);
      const active = id === selected;
      const selectKey = () => { if (!disabled) select(key); };
      return <g key={id} className={active ? 'lily-key active' : 'lily-key'} role="button" tabIndex={0}
        aria-label={`${keyLabel(key)} (${id})`} aria-pressed={active} aria-disabled={disabled}
        onClick={selectKey} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectKey(); } }}>
        <title>{`${keyLabel(key)} (${id})`}</title>
        <rect x={key.x + 0.04} y={key.y + 0.04} width={key.w - 0.08} height={key.h - 0.08} rx={0.11}/>
        {key.w2 !== undefined && (key.w2 !== key.w || key.h2 !== key.h) &&
          <rect x={key.x + (key.x2 ?? 0) + 0.04} y={key.y + (key.y2 ?? 0) + 0.04}
            width={key.w2 - 0.08} height={(key.h2 ?? key.h) - 0.08} rx={0.11}/>}
        <text x={key.x + key.w / 2} y={key.y + Math.min(key.h, 1) / 2} dominantBaseline="middle" textAnchor="middle">{keyLabel(key)}</text>
      </g>;
    })}
  </svg>;
}

function SensorChart({reading, points, unlock}: {reading?: Reading; points: number[]; unlock?: ReactNode}) {
  const hasData = reading?.unlocked;
  const current = points[points.length - 1];
  return <section className="lily-card" aria-label="实时传感器监看">
    <h3>实时传感器监看</h3>
    {!hasData && unlock}
    <div className="lily-metrics">
      <span>原始 ADC<strong>{hasData ? reading.raw : '—'}</strong></span>
      <span>静止基线<strong>{hasData ? reading.baseline : '—'}</strong></span>
      <span>触底校准值<strong>{hasData ? reading.bottom : '—'}</strong></span>
      <span>校准信号比例<strong>{hasData && current !== undefined ? `${current.toFixed(1)}%` : '—'}</strong></span>
    </div>
    <svg className="lily-chart" viewBox="0 0 600 112" role="img" aria-label="校准信号比例随时间变化的曲线">
      {[8, 56, 104].map(y => <line key={y} x1="36" x2="596" y1={y} y2={y}/>)}
      <text x="1" y="12">100%</text><text x="11" y="60">50%</text><text x="18" y="108">0%</text>
      {hasData && points.length > 1 && <polyline points={points.map((p, i) => `${596 - (points.length - i - 1) * 560 / 89},${104 - p * 0.96}`).join(' ')}/>}
    </svg>
    <p>{hasData && reading.bottom <= reading.baseline ? '触底校准值不高于静止基线，仍可查看原始 ADC。' : '曲线显示最近约 6 秒的校准信号比例。'}</p>
  </section>;
}

export function Lily60RT({send, keys, unlock, paused = false}: {
  send: Send; keys: PhysicalKey[]; unlock?: ReactNode; paused?: boolean;
}) {
  const [keyId, setKeyId] = useState('0,0');
  const selected = keys.find(k => coordinates(k) === keyId) ?? keys[0];
  const row = selected?.row;
  const col = selected?.col;
  const [ready, setReady] = useState(false);
  const [reading, setReading] = useState<Reading>();
  const [points, setPoints] = useState<number[]>([]);
  const [draft, setDraft] = useState<Settings>();
  const [global, setGlobal] = useState<Settings>();
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('正在读取 Lily60 固件…');
  const pending = useRef(false);

  useEffect(() => {
    let live = true;
    setReady(false);
    setNotice('正在读取 Lily60 固件…');
    void (async () => {
      try {
        const info = await rtCommand(send, INFO);
        if (info[2] !== 1 || info[3] !== 5 || info[4] !== 15) throw new Error('固件版本不匹配');
        const result = await rtCommand(send, GET_GLOBAL);
        if (!live) return;
        setGlobal({mode: result[2], ...thresholds(result, 3)});
        setReady(true);
        setNotice('');
      } catch {
        if (live) setNotice('无法读取 RT 设置。请刷入支持逐键 RT 的 Lily60 固件并重新连接。');
      }
    })();
    return () => { live = false; };
  }, [send]);

  useEffect(() => {
    setDraft(undefined);
    setReading(undefined);
    setPoints([]);
  }, [row, col, send]);

  useEffect(() => {
    if (!ready || paused || row === undefined || col === undefined) return;
    let active = true;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      let delay = 70;
      try {
        if (!pending.current && !document.hidden) {
          const data = await rtCommand(send, GET_KEY, row, col);
          if (!active) return;
          const next = {
            settings: {mode: data[4], ...thresholds(data, 17)}, effective: thresholds(data, 6),
            enabled: Boolean(data[5]), raw: uint16(data, 10), baseline: uint16(data, 12),
            bottom: uint16(data, 14), unlocked: data[16] === 1,
          };
          setReading(next);
          setNotice(previous => previous === '实时读取中断，正在重试。' ? '' : previous);
          setDraft(previous => previous ?? next.settings);
          if (next.unlocked && next.bottom > next.baseline) {
            const percent = 100 * (next.raw - next.baseline) / (next.bottom - next.baseline);
            setPoints(previous => [...previous.slice(-89), Math.max(0, Math.min(100, percent))]);
          } else {
            setPoints(previous => previous.length ? [] : previous);
            if (!next.unlocked) delay = 350;
          }
        }
      } catch {
        if (active) setNotice('实时读取中断，正在重试。');
        delay = 600;
      } finally {
        if (active) timer = setTimeout(poll, delay);
      }
    };
    void poll();
    return () => { active = false; clearTimeout(timer); };
  }, [row, col, paused, ready, send]);

  const save = async (event: FormEvent, settings: Settings, key?: PhysicalKey) => {
    event.preventDefault();
    pending.current = true;
    setSaving(true);
    try {
      if (key) await rtCommand(send, SET_KEY, key.row, key.col, ...encode(settings));
      else await rtCommand(send, SET_GLOBAL, ...encode(settings));
      setNotice('已保存到键盘');
    } catch (error) {
      setNotice(error instanceof Error ? error.message : '保存失败');
    } finally {
      setSaving(false);
      pending.current = false;
    }
  };

  return <div className="lily-panel">
    <h2>逐键 RT 与传感器监看</h2>
    <p className="lily-status" role="status">{notice || '点击当前配列中的按键，查看它的 RT 设置和曲线。'}</p>
    <KeyboardMap keys={keys} selected={selected ? coordinates(selected) : ''} select={k => setKeyId(coordinates(k))} disabled={saving}/>
    {ready && <>
      <SensorChart reading={reading} points={points} unlock={unlock}/>
      <div className="lily-columns">
        {selected && <section className="lily-card">
          <h3>{keyLabel(selected)} · {coordinates(selected)}</h3>
          {reading && <div className="lily-effective">
            <strong>{reading.settings.mode === 0 ? '来自全局设置' : '来自单键设置'}</strong>
            <span>{reading.enabled ? 'RT 已启用' : 'RT 已关闭，以下为已配置的 RT 数值'}</span>
            <div>{fieldNames.map(field => <span key={field}>{names[field]} {reading.effective[field]}</span>)}</div>
          </div>}
          {draft && <SettingsForm title="单键模式" value={draft} onChange={setDraft} onSave={event => void save(event, draft, selected)}
            disabled={saving || paused} modeOptions={['沿用全局', '单独启用 RT', '单独关闭 RT（APC）']}/>}
        </section>}
        {global && <section className="lily-card"><h3>全局默认值</h3>
          <SettingsForm title="全局模式" value={global} onChange={setGlobal} onSave={event => void save(event, global)}
            disabled={saving || paused} modeOptions={['APC', 'Rapid Trigger']}/>
        </section>}
      </div>
    </>}
  </div>;
}
