// SPDX-License-Identifier: GPL-2.0-or-later
import {memo, useCallback, useEffect, useRef, useState, type CSSProperties, type FormEvent, type ReactNode} from 'react';
import {encode, GET_GLOBAL, GET_KEY, GET_SENSOR_BATCH, INFO, rtCommand, SET_GLOBAL, SET_KEY, thresholds, uint16, type Send, type Settings, type Thresholds} from './protocol';
import labels from './physical-labels';
import './panel.css';

export type PhysicalKey = {
  row: number; col: number; x: number; y: number; w: number; h: number;
  x2?: number; y2?: number; w2?: number; h2?: number;
};

const coordinates = (key: PhysicalKey) => `${key.row},${key.col}`;
const labelsByPosition = labels as Record<string, string>;
const keyLabel = (key: PhysicalKey) => key.row === 0 && key.col === 13 && key.w > 1
  ? '⌫' : (labelsByPosition[coordinates(key)] ?? coordinates(key));
const names = {deadzone: '初始死区', press: '再次触发偏移', release: '释放偏移'};
const fieldNames = Object.keys(names) as Array<keyof Thresholds>;
const independentModes = [[1, '启用 RT'], [2, '关闭 RT（APC）']] as const;
const legacyModes = [[0, '沿用全局'], ...independentModes] as const;
const globalModes = [[0, 'APC'], [1, 'Rapid Trigger']] as const;

type Reading = {
  settings: Settings; effective: Thresholds; enabled: boolean;
  raw: number; baseline: number; bottom: number; unlocked: boolean;
};
type Signal = Pick<Reading, 'raw' | 'baseline' | 'bottom'>;
type Overview = Record<string, {raw: number; ratio?: number}>;
type ChartPoint = {time: number; ratio: number};

const MATRIX_ROWS = 5;
const MATRIX_COLS = 15;
const CURVE_INTERVAL = 40;
const CHART_DURATION = 6000;
const BATCH_INTERVAL = 100;
const LEGACY_READ_INTERVAL = 15;
const LEGACY_PAINT_INTERVAL = 90;

function signalRatio({raw, baseline, bottom}: Signal) {
  return bottom > baseline ? Math.max(0, Math.min(100, 100 * (raw - baseline) / (bottom - baseline))) : undefined;
}

function readSignal(data: ArrayLike<number>) {
  return {raw: uint16(data, 10), baseline: uint16(data, 12), bottom: uint16(data, 14)};
}

function SettingsForm({value, onChange, onSave, disabled, modeOptions, title}: {
  value: Settings; onChange: (value: Settings) => void; onSave: (event: FormEvent) => void;
  disabled: boolean; modeOptions: ReadonlyArray<readonly [number, string]>; title: string;
}) {
  return <form onSubmit={onSave} className="lily-form">
    <label className="lily-row"><span>{title}</span>
      <select value={value.mode} onChange={e => onChange({...value, mode: Number(e.target.value)})} disabled={disabled}>
        {modeOptions.map(([mode, label]) => <option key={mode} value={mode}>{label}</option>)}
      </select>
    </label>
    {fieldNames.map(field => <label key={field} className="lily-row"><span>{names[field]}</span>
      <input required type="number" min={1} max={field === 'deadzone' ? 1023 : 255} step={1}
        value={value[field] || ''} disabled={disabled}
        onChange={e => onChange({...value, [field]: Number(e.target.value)})}/>
    </label>)}
    <button type="submit" disabled={disabled}>保存到键盘</button>
  </form>;
}

const KeyboardMap = memo(function KeyboardMap({keys, selected, select, disabled, overview}: {
  keys: PhysicalKey[]; selected: string; select: (key: PhysicalKey) => void; disabled: boolean; overview: Overview;
}) {
  const left = Math.min(0, ...keys.map(k => k.x + Math.min(0, k.x2 ?? 0)));
  const right = Math.max(15, ...keys.map(k => k.x + Math.max(k.w, (k.x2 ?? 0) + (k.w2 ?? k.w))));
  const top = Math.min(0, ...keys.map(k => k.y + Math.min(0, k.y2 ?? 0)));
  const bottom = Math.max(5, ...keys.map(k => k.y + Math.max(k.h, (k.y2 ?? 0) + (k.h2 ?? k.h))));
  return <svg className="lily-keyboard" viewBox={`${left} ${top} ${right - left} ${bottom - top}`} aria-label="当前键盘配列">
    {keys.map(key => {
      const id = coordinates(key);
      const active = id === selected;
      const signal = overview[id];
      const ratio = signal?.ratio;
      const selectKey = () => { if (!disabled) select(key); };
      return <g key={id} className={active ? 'lily-key active' : 'lily-key'} role="button" tabIndex={0}
        aria-label={`${keyLabel(key)} (${id})`} aria-pressed={active} aria-disabled={disabled}
        style={{'--lily-signal': `${ratio ?? 0}%`} as CSSProperties}
        onClick={selectKey} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); selectKey(); } }}>
        <title>{`${keyLabel(key)} (${id})${signal ? ` · ADC ${signal.raw}` : ''}`}</title>
        <rect x={key.x + 0.04} y={key.y + 0.04} width={key.w - 0.08} height={key.h - 0.08} rx={0.11}/>
        {key.w2 !== undefined && (key.w2 !== key.w || key.h2 !== key.h) &&
          <rect x={key.x + (key.x2 ?? 0) + 0.04} y={key.y + (key.y2 ?? 0) + 0.04}
            width={key.w2 - 0.08} height={(key.h2 ?? key.h) - 0.08} rx={0.11}/>}
        <text x={key.x + key.w / 2} y={key.y + 0.33} dominantBaseline="middle" textAnchor="middle">{keyLabel(key)}</text>
        <text className="lily-key-reading" x={key.x + key.w / 2} y={key.y + 0.69}
          dominantBaseline="middle" textAnchor="middle" aria-hidden="true">{signal?.raw ?? '—'}</text>
      </g>;
    })}
  </svg>;
});

function SensorChart({reading, points, unlock}: {reading?: Reading; points: ChartPoint[]; unlock?: ReactNode}) {
  const hasData = reading?.unlocked;
  const latest = points[points.length - 1];
  return <section className="lily-card lily-sensor" aria-label="实时传感器监看">
    <h2>选中键的实时曲线</h2>
    {!hasData && unlock}
    <div className="lily-metrics">
      <span>原始 ADC<strong>{hasData ? reading.raw : '—'}</strong></span>
      <span>静止基线<strong>{hasData ? reading.baseline : '—'}</strong></span>
      <span>触底校准值<strong>{hasData ? reading.bottom : '—'}</strong></span>
      <span>校准信号比例<strong>{hasData && latest ? `${latest.ratio.toFixed(1)}%` : '—'}</strong></span>
    </div>
    <svg className="lily-chart" viewBox="0 0 600 158" role="img" aria-label="校准信号比例随时间变化的曲线">
      {[10, 73, 136].map(y => <line key={y} x1="40" x2="596" y1={y} y2={y}/>)}
      {[40, 132.67, 225.33, 318, 410.67, 503.33, 596].map(x => <line key={x} x1={x} x2={x} y1="10" y2="136"/>)}
      <text x="2" y="14">100%</text><text x="9" y="77">50%</text><text x="16" y="140">0%</text>
      <text x="40" y="154">约 6 秒前</text><text x="596" y="154" textAnchor="end">现在</text>
      {hasData && latest && points.length > 1 && <polyline points={points.map(({time, ratio}) =>
        `${596 - (latest.time - time) * 556 / CHART_DURATION},${136 - ratio * 1.26}`).join(' ')}/>}
    </svg>
    <p>{hasData && reading.bottom <= reading.baseline ? '触底校准值不高于静止基线，仍可查看原始 ADC。' : '曲线显示最近约 6 秒的校准信号比例。'}</p>
  </section>;
}

export function Lily60RT({send, keys, unlock, paused = false}: {
  send: Send; keys: PhysicalKey[]; unlock?: ReactNode; paused?: boolean;
}) {
  const [keyId, setKeyId] = useState('0,0');
  const selected = keys.find(k => coordinates(k) === keyId) ?? keys[0];
  const row = selected?.row;
  const col = selected?.col;
  const keyPositions = keys.map(coordinates).join(' ');
  const [ready, setReady] = useState(false);
  const [sensorsPerReport, setSensorsPerReport] = useState(0);
  const [independentKeys, setIndependentKeys] = useState(false);
  const [reading, setReading] = useState<Reading>();
  const [overview, setOverview] = useState<Overview>({});
  const [points, setPoints] = useState<ChartPoint[]>([]);
  const [draft, setDraft] = useState<Settings>();
  const [global, setGlobal] = useState<Settings>();
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState('正在读取 Lily60 固件…');
  const pending = useRef(false);
  const selectKey = useCallback((key: PhysicalKey) => setKeyId(coordinates(key)), []);

  useEffect(() => {
    let live = true;
    setReady(false);
    setNotice('正在读取 Lily60 固件…');
    void (async () => {
      try {
        const info = await rtCommand(send, INFO);
        if (info[2] !== 1 || info[3] !== MATRIX_ROWS || info[4] !== MATRIX_COLS) throw new Error('固件版本不匹配');
        const independent = info[7] === 1;
        const result = independent ? undefined : await rtCommand(send, GET_GLOBAL);
        if (!live) return;
        setSensorsPerReport(info[6] <= 14 ? info[6] : 0);
        setIndependentKeys(independent);
        setGlobal(result && {mode: result[2], ...thresholds(result, 3)});
        setReady(true);
        setNotice('');
      } catch {
        if (live) setNotice('无法读取 RT 设置。请刷入支持逐键 RT 的 Lily60 固件并重新连接。');
      }
    })();
    return () => { live = false; };
  }, [send]);

  useEffect(() => {
    setDraft(undefined);
    setReading(undefined);
    setPoints([]);
  }, [row, col, send]);

  useEffect(() => setOverview({}), [keyPositions, send, paused]);

  useEffect(() => {
    if (!ready || paused || row === undefined || col === undefined) return;
    const selectedId = `${row},${col}`;
    const positions = new Set(keyPositions.split(' '));
    const survey = [...positions].filter(position => position !== selectedId);
    let staged: Overview = {};
    let surveyIndex = 0;
    let batchIndex = 0;
    let frameStarted = 0;
    let nextPaint = 0;
    let unlocked = false;
    let nextCurve = 0;
    let nextOverview = 0;
    let active = true;
    let timer: ReturnType<typeof setTimeout>;
    const poll = async () => {
      let delay = document.hidden ? 180 : 45;
      const now = performance.now();
      try {
        if (!pending.current && !document.hidden) {
          if (now >= nextCurve) {
            const data = await rtCommand(send, GET_KEY, row, col);
            if (!active) return;
            const next = {
              settings: {mode: data[4], ...thresholds(data, 17)}, effective: thresholds(data, 6),
              enabled: Boolean(data[5]), unlocked: data[16] === 1, ...readSignal(data),
            };
            if (unlocked && !next.unlocked) {
              setOverview({});
              surveyIndex = 0;
              batchIndex = 0;
              staged = {};
            }
            unlocked = next.unlocked;
            setReading(next);
            setNotice(previous => previous === '实时读取中断，正在重试。' ? '' : previous);
            setDraft(previous => previous ?? next.settings);
            const percent = unlocked ? signalRatio(next) : undefined;
            const time = performance.now();
            setPoints(previous => percent === undefined ? [] :
              [...previous.filter(point => time - point.time < CHART_DURATION), {time, ratio: percent}]);
            if (unlocked && !sensorsPerReport) staged[selectedId] = {raw: next.raw, ratio: percent};
            nextCurve = now + (unlocked ? CURVE_INTERVAL : 350);
          } else if (unlocked && now >= nextOverview) {
            if (sensorsPerReport) {
              if (batchIndex === 0) frameStarted = now;
              const data = await rtCommand(send, GET_SENSOR_BATCH, batchIndex);
              if (!active) return;
              const first = batchIndex * sensorsPerReport;
              const end = Math.min(first + sensorsPerReport, MATRIX_ROWS * MATRIX_COLS);
              for (let index = first; index < end; index++) {
                const position = `${Math.floor(index / MATRIX_COLS)},${index % MATRIX_COLS}`;
                if (!positions.has(position)) continue;
                const value = uint16(data, 3 + 2 * (index - first));
                staged[position] = {raw: value & 1023, ratio: 100 * (value >> 10) / 63};
              }
              batchIndex++;
              if (end === MATRIX_ROWS * MATRIX_COLS) {
                setOverview(staged);
                staged = {};
                batchIndex = 0;
                nextOverview = frameStarted + BATCH_INTERVAL;
              }
            } else {
              if (survey.length) {
                const position = survey[surveyIndex];
                const [surveyRow, surveyCol] = position.split(',').map(Number);
                const data = await rtCommand(send, GET_KEY, surveyRow, surveyCol).catch(() => undefined);
                if (!active) return;
                if (data?.[16] === 1) {
                  const signal = readSignal(data);
                  staged[position] = {raw: signal.raw, ratio: signalRatio(signal)};
                }
                surveyIndex = (surveyIndex + 1) % survey.length;
              }
              nextOverview = now + LEGACY_READ_INTERVAL;
            }
          }
          if (!sensorsPerReport && now >= nextPaint && Object.keys(staged).length) {
            const updates = staged;
            staged = {};
            setOverview(previous => ({...previous, ...updates}));
            nextPaint = now + LEGACY_PAINT_INTERVAL;
          }
          delay = Math.max(0, Math.min(nextCurve, unlocked ? nextOverview : nextCurve) - performance.now());
        }
      } catch {
        if (active) setNotice('实时读取中断，正在重试。');
        batchIndex = 0;
        staged = {};
        delay = 350;
      } finally {
        if (active) timer = setTimeout(poll, delay);
      }
    };
    void poll();
    return () => { active = false; clearTimeout(timer); };
  }, [row, col, keyPositions, paused, ready, send, sensorsPerReport]);

  const save = async (event: FormEvent, settings: Settings, key?: PhysicalKey) => {
    event.preventDefault();
    pending.current = true;
    setSaving(true);
    try {
      if (key) await rtCommand(send, SET_KEY, key.row, key.col, ...encode(settings));
      else await rtCommand(send, SET_GLOBAL, ...encode(settings));
      setNotice('已保存到键盘');
    } catch (error) {
      setNotice(error instanceof Error ? error.message : '保存失败');
    } finally {
      setSaving(false);
      pending.current = false;
    }
  };

  return <div className="lily-panel lily-rt">
    <header>
      <h1>逐键 RT 与传感器监看</h1>
      <p className="lily-status" role="status">{notice || '点击按键查看实时曲线和当前生效的 RT 设置。'}</p>
    </header>
    <div className="lily-workspace">
      <div className="lily-observation">
        <section className="lily-card lily-overview">
          <div className="lily-overview-header">
            <div><h2>全键传感器图</h2><p>键帽数字为原始 ADC，颜色表示校准信号比例。</p></div>
            <span>{!ready ? '等待连接' : reading?.unlocked ? `${Object.keys(overview).length || '…'} / ${keys.length} 键 · ${sensorsPerReport ? '批量刷新' : '逐键更新'}` : '等待读数'}</span>
          </div>
          <div className="lily-keyboard-scroll">
            <KeyboardMap keys={keys} selected={selected ? coordinates(selected) : ''} select={selectKey} disabled={saving} overview={overview}/>
          </div>
          <div className="lily-scale" aria-label="校准信号比例图例"><span>0%</span><i/><span>100%</span></div>
        </section>
        {ready && <SensorChart reading={reading} points={points} unlock={unlock}/>}
      </div>
      {ready && <aside className="lily-rt-settings" aria-label="RT 设置">
        {selected && <section className="lily-card">
          <h2>单键设置</h2>
          <h3>{keyLabel(selected)} · {coordinates(selected)}</h3>
          {reading && <div className="lily-effective">
            <strong>{independentKeys ? '当前生效设置' : reading.settings.mode === 0 ? '来自全局设置' : '来自单键设置'}</strong>
            <span>{reading.enabled ? 'RT 已启用' : 'RT 已关闭，以下为已配置的 RT 数值'}</span>
            <div>{fieldNames.map(field => <span key={field}>{names[field]} {reading.effective[field]}</span>)}</div>
          </div>}
          {draft && <SettingsForm title="单键模式" value={draft} onChange={setDraft} onSave={event => void save(event, draft, selected)}
            disabled={saving || paused} modeOptions={independentKeys ? independentModes : legacyModes}/>}
        </section>}
        {global && <section className="lily-card"><h2>全局默认值</h2>
          <SettingsForm title="全局模式" value={global} onChange={setGlobal} onSave={event => void save(event, global)}
            disabled={saving || paused} modeOptions={globalModes}/>
        </section>}
      </aside>}
    </div>
  </div>;
}
