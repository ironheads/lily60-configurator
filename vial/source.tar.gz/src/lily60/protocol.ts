// SPDX-License-Identifier: GPL-2.0-or-later
export type Send = (packet: number[]) => Promise<ArrayLike<number>>;

export const INFO = 0x20;
export const GET_KEY = 0x21;
export const SET_KEY = 0x22;
export const GET_GLOBAL = 0x23;
export const SET_GLOBAL = 0x24;

export async function rtCommand(send: Send, op: number, ...args: number[]) {
  const request = [0xfd, op, ...args];
  const result = await send(request);
  if (result.length !== 32 || request.some((byte, index) => result[index] !== byte)) {
    throw new Error('键盘没有返回有效的 Lily60 RT 响应');
  }
  if (result[31] !== 0xa5) throw new Error('键盘拒绝了这次读取或保存');
  return result;
}

export type Thresholds = {deadzone: number; press: number; release: number};
export type Settings = Thresholds & {mode: number};

export const uint16 = (data: ArrayLike<number>, offset: number) =>
  data[offset] | (data[offset + 1] << 8);

export const thresholds = (data: ArrayLike<number>, offset: number): Thresholds => ({
  deadzone: uint16(data, offset), press: data[offset + 2], release: data[offset + 3],
});

export const encode = ({mode, deadzone, press, release}: Settings) =>
  [mode, deadzone & 255, deadzone >> 8, press, release];

export async function lightingCommand(send: Send, channel: number, field: number, values: number[] = []) {
  const operation = values.length ? 7 : 8;
  const result = await send([0xfd, operation, channel, field, ...values]);
  if (result.length !== 32 || result[0] !== 0xfc || result[1] !== operation || result[2] !== channel || result[3] !== field) {
    throw new Error('键盘没有确认灯光设置');
  }
  return [result[4], result[5]];
}
