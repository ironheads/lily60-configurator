export function track(_path: string, _title?: string): void {}
