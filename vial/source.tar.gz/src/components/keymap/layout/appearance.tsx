import type { CSSProperties, ReactNode } from "react";

/** Right-click assign target — one cap, or one encoder rotation direction. */
export type PreviewContextTarget =
  | { kind: "key"; row: number; col: number }
  | { kind: "encoder"; index: number; direction: 0 | 1 };

/** The active 键帽上色 brush: either a palette color or the eraser. */
export type PaintBrush = { kind: "color"; hex: string } | { kind: "eraser" };

/** Opt-in paint-mode wiring passed to `KeyboardLayoutPreview` — see its `paint` prop. */
export interface PaintTool {
  /** Selected brush, or `null` while 颜色管理区 is open but nothing is picked yet — clicks are then inert. */
  tool: PaintBrush | null;
  /** Called with the clicked key's row/col; the caller decides what a `null` tool means (typically a no-op). */
  onPaint: (row: number, col: number) => void;
}

/**
 * Builds a CSS `cursor` value for 键帽上色 paint mode: a small circular
 * data-URI SVG dot filled with the selected color, a dashed outline ring for
 * the eraser, or the plain default pointer while nothing is picked yet.
 */
export function paintCursor(tool: PaintBrush | null): string {
  if (!tool) {
    return "default";
  }
  const fill = tool.kind === "color" ? tool.hex : "none";
  const stroke = tool.kind === "color" ? "white" : "#666";
  const dash = tool.kind === "eraser" ? " stroke-dasharray='3 2'" : "";
  const svg =
    `<svg xmlns='http://www.w3.org/2000/svg' width='22' height='22'>` +
    `<circle cx='11' cy='11' r='8' fill='${fill}' stroke='${stroke}' stroke-width='2'${dash}/>` +
    `</svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}") 11 11, pointer`;
}

/**
 * Display size (显示尺寸) is a pure *visual* zoom: the board is always laid out
 * at {@link BASE_UNIT} px per KLE unit and then scaled as a whole via a CSS
 * transform ({@link KeyboardZoom}). Nothing is re-measured or re-rendered at a
 * different size, so labels, icons, borders, shadows, case thickness and corner
 * radii all grow and shrink together — which is what this setting is for. The
 * factors match the px-per-unit sizes the board renders at (32/44/56/68/82); `l`
 * is the natural 1× (BASE_UNIT) size.
 */
export type PreviewSize = "xs" | "s" | "m" | "l" | "xl";
export const BASE_UNIT = 68;
export const PREVIEW_ZOOM: Record<PreviewSize, number> = {
  xs: 32 / BASE_UNIT,
  s: 44 / BASE_UNIT,
  m: 56 / BASE_UNIT,
  l: 1,
  xl: 82 / BASE_UNIT,
};

/**
 * Key spacing (按键间距) as a 4-level setting. The gap isn't an absolute px
 * value — each level is a fraction of one keycap's width, so it stays
 * proportional however the cap ratios are tuned.
 */
export type SpacingLevel = "s" | "m" | "l" | "xl";
export const SPACING_LEVELS: SpacingLevel[] = ["s", "m", "l", "xl"];
export const SPACING_RATIOS: Record<SpacingLevel, number> = { s: 0.05, m: 0.09, l: 0.13, xl: 0.18 };

/**
 * Keycap width (键帽宽度) as a 4-level setting: the fraction of one pitch cell
 * the cap fills. Independent of spacing — a narrower cap reveals more plate
 * between keys without moving them, so the board size stays put. `xl` = 1.0
 * means the cap fills the whole cell (gap comes purely from spacing).
 */
export const CAP_RATIOS: Record<SpacingLevel, number> = { s: 0.8, m: 0.87, l: 0.93, xl: 1.0 };

/**
 * Case corner radius (外壳圆角) as a 4-level setting, in px at 1×. Unlike spacing
 * it's an absolute px value rather than a ratio; the visual zoom scales it along
 * with everything else.
 */
export const CASE_RADIUS_PX: Record<SpacingLevel, number> = { s: 4, m: 10, l: 18, xl: 28 };

/**
 * Keycap corner radius (键帽圆角) as a 3-level setting, in px at 1×, applied via
 * the `--key-radius` CSS var consumed by `.keyboard-layout .key` in index.css.
 * Only s/m/l are offered (no `xl`) — unlike the 4-level knobs above, rounder
 * than `l` starts looking like a pill rather than a keycap.
 */
export type KeycapRadiusLevel = "s" | "m" | "l";
export const KEYCAP_RADIUS_LEVELS: KeycapRadiusLevel[] = ["s", "m", "l"];
export const KEYCAP_RADIUS_PX: Record<KeycapRadiusLevel, number> = { s: 2, m: 4, l: 8 };

/**
 * Keycap label font size (字体大小) as a 4-level setting: a multiplier applied to
 * the label/icon size via the `--key-font-scale` CSS var, so `m` = 1× is the
 * baseline and the others scale the on-cap text without touching cap geometry.
 *
 * Independent of {@link PreviewSize}: display size is a whole-board "photo" zoom
 * (see {@link KeyboardZoom}) that scales labels along with everything else, so it
 * has nothing to do with this label-relative-to-cap knob. They were once the same
 * type only because both happened to be 4-level s→xl ladders; the display-size
 * ladder now also has an `xs` for auto-fit, which must not leak into font size.
 */
export type FontSize = "s" | "m" | "l" | "xl";
export const FONT_SIZES: FontSize[] = ["s", "m", "l", "xl"];
export const FONT_SCALES: Record<FontSize, number> = { s: 0.8, m: 1, l: 1.25, xl: 1.5 };

/**
 * Keycap label position (字体位置) within the cap face: top-left corner, centered
 * (default), or bottom-center. Maps to a `key-pos-*` modifier class on each key
 * ({@link fontPositionClass}); `center` needs no class (it's the default flex
 * alignment).
 */
export type FontPosition = "top-left" | "center" | "center-bottom";
export const FONT_POSITIONS: FontPosition[] = ["top-left", "center", "center-bottom"];

/** Modifier class for a label position; empty for the default `center`. */
export function fontPositionClass(pos: FontPosition): string {
  return pos === "center" ? "" : ` key-pos-${pos}`;
}

/**
 * Board rendering style (立体感/风格), 4 states: `wireframe` (线稿 — outline only,
 * no fill), `default` (flat fill, no shading), `relief` (浮雕 — highlight/shadow
 * 3D shading, what the old `depth` boolean's `true` meant), and `3d` (未实现 —
 * reserved for a future true-3D render; renders identically to `default` until
 * then). Only `default`/`relief` are reachable today, via the 立体感 toggle on
 * the 键盘配色 page (`KeyboardColorPanel`); `wireframe`/`3d` are wired through the
 * rendering pipeline but have no UI entry point yet.
 */
export type PreviewStyle = "wireframe" | "default" | "relief" | "3d";
export const PREVIEW_STYLES: PreviewStyle[] = ["wireframe", "default", "relief", "3d"];
export const DEFAULT_PREVIEW_STYLE: PreviewStyle = "relief";

/** Defaults for the tunable case/plate appearance. */
export const DEFAULT_KEY_SPACING: SpacingLevel = "s";
export const DEFAULT_FONT_SIZE: FontSize = "m";
export const DEFAULT_FONT_COLOR = "#1a1a1a";
export const DEFAULT_FONT_POSITION: FontPosition = "center";
export const DEFAULT_KEYCAP_WIDTH: SpacingLevel = "xl";
export const DEFAULT_CASE_RADIUS: SpacingLevel = "l";
export const DEFAULT_KEYCAP_RADIUS: KeycapRadiusLevel = "m";
export const DEFAULT_CASE_THICKNESS = 15;
export const DEFAULT_CASE_COLOR = "#b0b0b0";
export const DEFAULT_PLATE_COLOR = "#8a8a8a";
/** Default outline color for wireframe (线稿) style — caps/encoders/dual-role hold band. Overridable per-board via `colorOverride` (KeyboardLayoutEditor) or the `wireframeLineColor` prop (KeyboardLayoutPreview). */
export const DEFAULT_WIREFRAME_LINE_COLOR = "#c4c4c4";
/**
 * Forced 字体颜色/线稿颜色 for 线稿 (wireframe) style while the app is in dark
 * mode: legibility on the dark app background trumps whatever `fontColor`/
 * `wireframeLineColor` the user configured on 键盘配色 (a dark-on-dark pick would
 * make the whole board disappear). Does not apply when `colorOverride` is set
 * (KeyboardLayoutEditor) — that's a deliberate per-board design choice (e.g.
 * NewHomePage's hero strip) independent of the app's theme toggle, not a "user
 * config" this override is meant to defeat.
 */
export const WIREFRAME_DARK_COLOR = "#FEF8F7";

export interface PreviewAppearance {
  /** Key spacing level (按键间距); sets the pitch, so it scales the whole board. */
  spacing?: SpacingLevel;
  /** Keycap width level (键帽宽度); fraction of a pitch cell the cap fills. */
  keycapWidth?: SpacingLevel;
  /** Case corner radius level (外壳圆角). */
  caseRadius?: SpacingLevel;
  /** Keycap corner radius level (键帽圆角). */
  keycapRadius?: KeycapRadiusLevel;
  /** Case bezel thickness in px around the plate (外壳厚度). */
  caseThickness?: number;
  /** Case (外壳) fill color. */
  caseColor?: string;
  /** Plate (定位板) fill color the keys sit on. */
  plateColor?: string;
  /** Wireframe (线稿) style outline color — see {@link DEFAULT_WIREFRAME_LINE_COLOR}. */
  wireframeLineColor?: string;
  /** Whether each keycap draws a thin outline (键帽边框). Default off. */
  keycapBorder?: boolean;
  /** Board rendering style (立体感/风格) — see {@link PreviewStyle}. */
  style?: PreviewStyle;
  /** Keycap label font size level (字体大小). */
  fontSize?: FontSize;
  /** Keycap label text/icon color (字体颜色). */
  fontColor?: string;
  /** Keycap label position within the cap face (字体位置). */
  fontPosition?: FontPosition;
}

/**
 * `PITCH` is the per-unit advance (one pitch cell); positions and sizes both
 * scale by it and each keycap is then inset by `inset` (the gap between adjacent
 * caps = `PITCH - cap`). A 1u cap is therefore always `PITCH - inset = cap` wide,
 * decoupled from position: spacing grows the pitch (board), keycap width shrinks
 * the cap within its cell — neither disturbs the other.
 *
 * `pad` offsets every shape by a fixed px amount on both axes so the plate
 * shows an even margin on all four sides — without it the top/left keys sit
 * flush against the plate edge while only the bottom/right keys leave their
 * inter-key gap. Callers pass {@link AppearanceMetrics.plateMargin} here
 * rather than `inset` itself, since the plate margin and the inter-key gap
 * are independently configurable (see `PLATE_MARGIN_RATIO`); `plateWidth`/
 * `plateHeight` must be sized to match — see the call sites.
 */
export function shapeStyle(
  s: { x: number; y: number; width: number; height: number; rotationAngle: number; rotationX: number; rotationY: number },
  shiftX: number,
  shiftY: number,
  PITCH: number,
  inset: number,
  pad: number,
): CSSProperties {
  const style: CSSProperties = {
    left: (s.x + shiftX) * PITCH + pad,
    top: (s.y + shiftY) * PITCH + pad,
    width: s.width * PITCH - inset,
    height: s.height * PITCH - inset,
  };
  if (s.rotationAngle) {
    style.transform = `rotate(${s.rotationAngle}deg)`;
    style.transformOrigin = `${(s.rotationX - s.x) * PITCH}px ${(s.rotationY - s.y) * PITCH}px`;
  }
  return style;
}

/**
 * How much wider than the inter-key gap (`inset`) the plate's margin around
 * the outermost caps is. Decoupled so the two can be tuned independently —
 * see {@link AppearanceMetrics.plateMargin}.
 */
const PLATE_MARGIN_RATIO = 1.5;

/** Derived px geometry for the appearance settings, at 1× (pre-zoom). */
export interface AppearanceMetrics {
  /** Per-unit advance (one pitch cell), in px. */
  PITCH: number;
  /** Gap between adjacent caps, in px. */
  inset: number;
  /** Margin between the plate's edge and the outermost caps, in px — independent of `inset`. */
  plateMargin: number;
  /** Case outer corner radius, in px. */
  outerRadius: number;
  /** Plate inner corner radius, kept concentric with the case, in px. */
  innerRadius: number;
  /** Whether the case bezel is drawn at all (thickness > 0). */
  showCase: boolean;
  /** Visual zoom factor for the finished board — see {@link KeyboardZoom}. */
  zoom: number;
}

/**
 * Resolves the appearance knobs into the concrete px metrics both
 * {@link KeyboardLayoutPreview} and the interactive KeyboardLayoutEditor render from,
 * so the two boards stay pixel-identical in geometry. Keycap width sets the cap
 * size, key spacing sets the (constant) gap, and the pitch is their sum — so each
 * knob is independent.
 *
 * These are always the 1× metrics: display size doesn't enter the layout math at
 * all, it only comes back out as `zoom` for the caller's {@link KeyboardZoom}.
 */
export function appearanceMetrics(
  size: PreviewSize,
  spacing: SpacingLevel,
  keycapWidth: SpacingLevel,
  caseRadius: SpacingLevel,
  caseThickness: number,
): AppearanceMetrics {
  const cap = BASE_UNIT * CAP_RATIOS[keycapWidth];
  const inset = BASE_UNIT * SPACING_RATIOS[spacing];
  const plateMargin = inset * PLATE_MARGIN_RATIO;
  const PITCH = cap + inset;
  // Concentric corners: the plate's inner radius is the case's outer radius less
  // the bezel thickness, so the two arcs stay parallel. Clamp at 5 — once the
  // bezel is thicker than the outer radius the inner corner is essentially square.
  const outerRadius = CASE_RADIUS_PX[caseRadius];
  const innerRadius = Math.max(5, outerRadius - caseThickness + 5);
  return {
    PITCH,
    inset,
    plateMargin,
    outerRadius,
    innerRadius,
    showCase: caseThickness > 0,
    zoom: PREVIEW_ZOOM[size],
  };
}

/**
 * Scales a finished board (case + plate + caps) as a single visual unit.
 *
 * A CSS transform doesn't affect layout, so the wrapper is given the scaled box
 * explicitly — `width`/`height` are the board's natural size times the zoom —
 * and the inner element is scaled from its top-left corner to fill exactly that
 * box. Surrounding content therefore flows around the board at its apparent
 * size, with no gap or overlap.
 *
 * Anything using viewport coordinates (the hover card, the right-click cascade)
 * must stay *outside* this wrapper: a transformed ancestor becomes the
 * containing block for `position: fixed` descendants, which would both offset
 * and scale them.
 *
 * The wrapper is rendered even at 1×, so switching display size only animates
 * the two inline values (`.keyboard-zoom` transitions them in index.css) instead
 * of mounting/unmounting nodes mid-transition.
 */
export function KeyboardZoom({
  zoom,
  width,
  height,
  live = false,
  children,
}: {
  zoom: number;
  /** Natural (1×) outer width of the board, in px. */
  width: number;
  /** Natural (1×) outer height of the board, in px. */
  height: number;
  /**
   * True while auto-fit is driving the zoom, which changes it continuously as
   * the container resizes. Drops the size transition so the board tracks the
   * window exactly instead of easing toward each intermediate width.
   */
  live?: boolean;
  children: ReactNode;
}) {
  return (
    <div
      className={"keyboard-zoom" + (live ? " keyboard-zoom-live" : "")}
      style={{ width: width * zoom, height: height * zoom }}
    >
      <div style={{ width, height, transform: `scale(${zoom})`, transformOrigin: "top left" }}>
        {children}
      </div>
    </div>
  );
}
