import { useState } from "react";
import { Icon } from "@iconify/react";
import { useI18n, type Lang } from "../../../contexts/i18n.tsx";
import { useTheme } from "../../../contexts/theme.tsx";
import { DebugLogToggle } from "../../common/DebugLogToggle.tsx";
import { SettingsRow } from "../../qmk/QmkSettingsPanel.tsx";

/**
 * Wipe every localStorage entry this app owns (all `vialite-` keys: keyboard
 * style/appearance, theme, language, sidebar geometry, ...) AND revoke every
 * authorized WebHID device, then reload so all contexts re-initialise from
 * their defaults and the app lands on the connect page instead of silently
 * auto-reconnecting.
 *
 * Revoking the HID grants matters: localStorage and the WebHID permission
 * store are independent. Clearing only localStorage would leave the keyboard
 * still authorized, so App.tsx's `navigator.hid.getDevices()` auto-reconnect
 * would jump straight back into the config page on reload — the "cache didn't
 * get cleared" symptom. `HIDDevice.forget()` drops that grant.
 */
async function clearSiteCache() {
  const keys: string[] = [];
  for (let i = 0; i < window.localStorage.length; i++) {
    const key = window.localStorage.key(i);
    if (key?.startsWith("vialite-")) {
      keys.push(key);
    }
  }
  keys.forEach((key) => window.localStorage.removeItem(key));

  // Best effort — forget() may be unavailable on older browsers, and a single
  // failing device shouldn't block the reload.
  try {
    const devices = await navigator.hid?.getDevices?.();
    if (devices) {
      await Promise.all(devices.map((d) => d.forget?.()));
    }
  } catch (err) {
    console.error("[vialite] failed to forget HID devices during cache clear:", err);
  }

  window.location.reload();
}

/**
 * The 网站设置 (Website Settings) page: preferences scoped to this configurator
 * itself, not the connected keyboard. A single grouped `list` — General
 * (language + theme). All choices persist to localStorage via their respective
 * contexts.
 */
export function SiteSettingsPanel() {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const [clearConfirmOpen, setClearConfirmOpen] = useState(false);

  return (
    <div className="flex flex-col gap-6">
      <section>
        <h2 className="mb-2 text-sm font-semibold text-brand-on-surface-variant">{t("siteGeneralTitle")}</h2>
        <ul className="list rounded-box border border-brand-outline/30">
          <SettingsRow
            icon={<Icon icon="mdi:web" className="h-4.5 w-4.5" />}
            label={t("languageTitle")}
            description={t("languageDesc")}
            control={
              <select
                className="select select-sm w-36"
                value={lang}
                onChange={(e) => setLang(e.target.value as Lang)}
                aria-label={t("languageTitle")}
              >
                <option value="zh">中文</option>
                <option value="en">English</option>
                <option value="ja">日本語</option>
                <option value="fr">Français</option>
              </select>
            }
          />
          <SettingsRow
            icon={<Icon icon="mdi:theme-light-dark" className="h-4.5 w-4.5" />}
            label={t("themeTitle")}
            description={t("themeDesc")}
            control={
              <select
                className="select select-sm w-32"
                value={theme}
                onChange={(e) => setTheme(e.target.value as "light" | "dark", e.currentTarget)}
                aria-label={t("themeTitle")}
              >
                <option value="light">{t("themeLight")}</option>
                <option value="dark">{t("themeDark")}</option>
              </select>
            }
          />
        </ul>
      </section>

      <section>
        <h2 className="mb-2 text-sm font-semibold text-brand-on-surface-variant">
          {t("siteDiagnosticsTitle")}
        </h2>
        <ul className="list rounded-box border border-brand-outline/30">
          <SettingsRow
            icon={<Icon icon="mdi:bug-outline" className="h-4.5 w-4.5" />}
            label={t("debugLogTitle")}
            description={t("debugLogDesc")}
            help={t("debugLogHint")}
            control={<DebugLogToggle />}
          />
        </ul>
      </section>

      <section>
        <h2 className="mb-2 text-sm font-semibold text-error">{t("siteDangerTitle")}</h2>
        <ul className="list rounded-box border border-error/40">
          <SettingsRow
            icon={<Icon icon="mdi:alert-outline" className="h-4.5 w-4.5 text-error" />}
            label={t("clearCacheTitle")}
            description={t("clearCacheDesc")}
            control={
              <button
                type="button"
                className="btn btn-error btn-outline btn-sm"
                onClick={() => setClearConfirmOpen(true)}
              >
                {t("clearCacheButton")}
              </button>
            }
          />
        </ul>
      </section>

      {clearConfirmOpen && (
        <div className="modal modal-open">
          <div className="modal-box">
            <h3 className="text-lg font-bold text-error">{t("clearCacheConfirmTitle")}</h3>
            <p className="py-2 text-sm text-brand-on-surface-variant">{t("clearCacheConfirmHint")}</p>
            <div className="modal-action">
              <button type="button" className="btn" onClick={() => setClearConfirmOpen(false)}>
                {t("cancel")}
              </button>
              <button type="button" className="btn btn-error" onClick={() => void clearSiteCache()}>
                {t("clearCacheConfirm")}
              </button>
            </div>
          </div>
          <button
            type="button"
            className="modal-backdrop"
            aria-label={t("cancel")}
            onClick={() => setClearConfirmOpen(false)}
          />
        </div>
      )}
    </div>
  );
}

