// SPDX-License-Identifier: GPL-2.0-or-later
import React, {useCallback} from 'react';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faWaveSquare} from '@fortawesome/free-solid-svg-icons';
import {getSelectedKeyDefinitions} from 'src/store/definitionsSlice';
import {getSelectedKeyboardAPI} from 'src/store/devicesSlice';
import {useAppSelector} from 'src/store/hooks';
import {Lily60RT} from './rt';
import type {Send} from './protocol';

export const Title = '逐键 RT';
export const Icon = () => <FontAwesomeIcon icon={faWaveSquare}/>;

export function Pane() {
  const api = useAppSelector(getSelectedKeyboardAPI);
  const keys = useAppSelector(getSelectedKeyDefinitions);
  const send = useCallback<Send>(async ([command, ...values]) => {
    if (!api) throw new Error('键盘未连接');
    return api.hidCommand(command as Parameters<typeof api.hidCommand>[0], values, 'Lily60 RT', false);
  }, [api]);
  return <>{api && <Lily60RT send={send} keys={keys}/>}</>;
}
