// SPDX-License-Identifier: GPL-2.0-or-later
import React, {useCallback} from 'react';
import {useTranslation} from 'react-i18next';
import {getSelectedDefinition, getSelectedKeyDefinitions} from 'src/store/definitionsSlice';
import {getIsSelectedDeviceReady, getSelectedKeyboardAPI} from 'src/store/devicesSlice';
import {reloadConnectedDevices} from 'src/store/devicesThunks';
import {useAppDispatch, useAppSelector} from 'src/store/hooks';
import {Lily60RT} from './rt';
import type {Send} from './protocol';

export function Lily60RTPage() {
  const {t} = useTranslation();
  const dispatch = useAppDispatch();
  const api = useAppSelector(getSelectedKeyboardAPI);
  const ready = useAppSelector(getIsSelectedDeviceReady);
  const definition = useAppSelector(getSelectedDefinition);
  const keys = useAppSelector(getSelectedKeyDefinitions);
  const send = useCallback<Send>(async ([command, ...values]) => {
    if (!api) throw new Error('键盘未连接');
    return api.hidCommand(command as Parameters<typeof api.hidCommand>[0], values, 'Lily60 RT', false);
  }, [api]);
  return <main className="lily-rt-page">
    {api && ready && definition?.vendorProductId === 0x68296001
      ? <Lily60RT send={send} keys={keys}/>
      : <div className="lily-panel lily-rt-connect">
        <h1>逐键 RT 与传感器监看</h1>
        <p>连接运行 VIA 四层固件的 Lily60，查看传感器读数和逐键设置。</p>
        <button type="button" onClick={() => dispatch(reloadConnectedDevices())}>{t('Authorize device')}</button>
      </div>}
  </main>;
}
